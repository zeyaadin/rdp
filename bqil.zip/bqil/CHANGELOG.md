# [6.5.0](https://github.com/WhiskeySockets/Baileys/compare/v6.4.2...v6.5.0) (2023-09-28)



## 6.4.2 (2023-09-28)



